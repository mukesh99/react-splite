import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './container/App';
import {Provider} from 'react-redux';
//import App from './App';

import {createStore, combineReducers, applyMiddleware} from 'redux';
import { createLogger } from 'redux-logger';
import './App.css';


const mathReducer =(state={
	result: 1,
	lastValues: [],
}, action)=>{
	switch(action.type)
	{
		case "ADD":
    state={
      ...state,
      result: state.result + action.payload,
      lastValues: [...state.lastValues, action.payload]
    };
    //state.lastValues.push(action.payload);
		break;
		case "SUB":
    state={
      ...state,
      result: state.result - action.payload,
      lastValues: [...state.lastValues, action.payload]
    };
    //state.lastValues.push(action.payload);
		break;
	}

	return state;
}

const userReducer =(state={
name: 'Mukesh',
age:32
}, action)=>{
	switch(action.type)
	{
		case "SETNAME":
    state={
      ...state,
    name:action.payload
    };
		break;
		case "SETAGE":
    state={
      ...state,
      age:action.payload
    };

		break;
	}

	return state;
}

const myLogger=(store) => (next) => (action) =>{
  console.log("loged Action:", action);
  next(action);
}

const store = createStore(combineReducers({math:mathReducer, user1:userReducer}), {},
applyMiddleware(createLogger()));
// once middleware set need to go command prompt and add npm inatsll redux-logger --save

store.subscribe(()=>{
	console.log("value is here", store.getState());
});


ReactDOM.render(
  <Provider store={store}>
  <App />
  </Provider>
  , document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
