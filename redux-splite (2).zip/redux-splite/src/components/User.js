import React, { Component } from 'react';


export const User = (props)=> {
    return(
      <div>
        <h1>This is User Page</h1>

        <div>User Name: {props.username}</div>
      </div>
    );


}
