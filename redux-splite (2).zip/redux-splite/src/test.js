import React, { Component } from 'react';
import {createStore} from 'redux';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
      My india is great
      </div>
    );
  }
}

export default App;
const initialState={
	result:1,
	lastValues: []
};

const reducer =(state=initialState, action)=>{
	switch(action.type)
	{
		case "ADD":
	//	state.result+=action.payload;
  state={
    //result: state.result,
    //valstValues: state.lastValues
    ...state,
    result: state.result + action.payload
  }
		break;
		case "SUB":
    state={
      result: state.result,
      valstValues: state.lastValues
    }
		break;
	}
	return state;
}

const store = createStore(reducer);

store.subscribe(()=>{
	console.log("value is here", store.getState());
});

store.dispatch({

	type:"ADD",
	payload:120
});
store.dispatch({

	type:"SUB",
	payload:90
});
