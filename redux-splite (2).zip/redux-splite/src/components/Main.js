import React, { Component } from 'react';


export const Main = (props)=>  {
    return(
      <div>
        <h1>This is Main Page</h1>

        <div><button onClick={()=> props.changeUsername()}>Change the Username</button></div>
      </div>
    );
}
