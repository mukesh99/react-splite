import React, { Component } from 'react';
import {createStore} from 'redux';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
      My india is great
      </div>
    );
  }
}

export default App;
const initialState={
	result: 1,
	lastValues: [],
  myname:"Mukesh"
};

const reducer =(state=initialState, action)=>{
	switch(action.type)
	{
		case "ADD":
    state={
      ...state,
      result: state.result + action.payload,
      lastValues: [...state.lastValues, action.payload]
    };
    state.lastValues.push(action.payload);
		break;
		case "SUB":
    state={
      ...state,
      result: state.result - action.payload,
      lastValues: [...state.lastValues, action.payload]
    };
    state.lastValues.push(action.payload);
		break;
	}

	return state;
}


const store = createStore(reducer);

store.subscribe(()=>{
	console.log("value is here", store.getState());
});

store.dispatch({

	type:"ADD",
	payload:120
});
store.dispatch({

	type:"ADD",
	payload:12
});
store.dispatch({

	type:"SUB",
	payload:90
});
