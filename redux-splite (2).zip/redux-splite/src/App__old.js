import React, { Component } from 'react';
import {createStore, combineReducers, applyMiddleware} from 'redux';
import { createLogger } from 'redux-logger';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
      My india is great
      </div>
    );
  }
}

export default App;

// const initial={
//   result:1,
//   lastValues:[],
//   age:32
// }
//
// const reducer =(state=initial,action)=>{
//   switch(action.type)
//   {
//     case 'ADD':
//     //state = state+action.payload
//     state={
//       ...state,
//     result:state.result+=action.payload,
//     lastValues: [...state.lastValues, action.payload]
//     }
//       break;
//       case 'SUB':
//       //state = state-action.payload
//       state={
//         ...state,
//       result:state.result-=action.payload,
//       lastValues: [...state.lastValues, action.payload]
//       }
//         break;
//   }
//   return state;
// }
//
// const store = createStore(reducer);
//
// store.subscribe(()=>{
//   console.log("My value Here ", store.getState());
// })
// store.dispatch({
// type:'ADD',
// payload:20
//
// })
// store.dispatch({
// type:'ADD',
// payload:35
//
// })
// store.dispatch({
// type:'SUB',
// payload:10
//
// })


// const initialstate={
// result:1,
//   lastValues:[]
// }
//
//
// const reducer =(state =initialstate, action)=>
// {
//   switch(action.type)
//   {
//     case "ADD":
//     //state = state+action.payload;
//     //result:state.result+=action.payload
//     state={
//       ...state,
//       result:state.result+=action.payload,
//         lastValues: [...state.lastValues, action.payload]
//     }
//     break;
//     case "SUB":
//     state={
//       ...state,
//       result:state.result-=action.payload,
//         lastValues: [...state.lastValues, action.payload]
//     }
//     break;
//   }
//
// return state;
// }
//
// const store = createStore(reducer);
//
// store.subscribe(()=>{
//   console.log("value is here", store.getState());
// });
//
// store.dispatch({
//   type:"ADD",
//   payload:20
// })
// store.dispatch({
//   type:"ADD",
//   payload:12
// })
// store.dispatch({
//   type:"SUB",
//   payload:5
// })

//


// Multiple reducer



const mathReducer =(state={
	result: 1,
	lastValues: [],
}, action)=>{
	switch(action.type)
	{
		case "ADD":
    state={
      ...state,
      result: state.result + action.payload,
      lastValues: [...state.lastValues, action.payload]
    };
    //state.lastValues.push(action.payload);
		break;
		case "SUB":
    state={
      ...state,
      result: state.result - action.payload,
      lastValues: [...state.lastValues, action.payload]
    };
    //state.lastValues.push(action.payload);
		break;
	}

	return state;
}

const userReducer =(state={
	result: 1,
	lastValues: [],
}, action)=>{
	switch(action.type)
	{
		case "SETNAME":
    state={
      ...state,
    name:action.payload
    };
		break;
		case "SETAGE":
    state={
      ...state,
      age:action.payload
    };

		break;
	}

	return state;
}

const myLogger=(store) => (next) => (action) =>{
  console.log("loged Action:", action);
  next(action);
}

const store = createStore(combineReducers({mathReducer, userReducer}), {},
applyMiddleware(createLogger()));
// once middleware set need to go command prompt and add npm inatsll redux-logger --save

store.subscribe(()=>{
	console.log("value is here", store.getState());
});
store.dispatch({

	type:"ADD",
	payload:120
});
store.dispatch({

	type:"ADD",
	payload:12
});
store.dispatch({
	type:"SETNAME",
	payload:"mukaeh"
});
store.dispatch({
	type:"SETAGE",
	payload:32
});
